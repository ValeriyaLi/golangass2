create function trigger_fb() returns trigger
    language plpgsql
as
$$
    BEGIN
        if tab1.date_of_birth is null then insert into tab1(date_of_birth) values ('2000-01-01');
        end if;
    end;
    $$;

alter function trigger_fb() owner to postgres;

