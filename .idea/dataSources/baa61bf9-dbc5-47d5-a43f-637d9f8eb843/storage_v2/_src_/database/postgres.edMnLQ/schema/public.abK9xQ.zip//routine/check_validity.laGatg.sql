create function check_validity(password text) returns boolean
    language plpgsql
as
$$
begin
    return password like 'a%b_';
end;
$$;

alter function check_validity(text) owner to postgres;

