create function for_h(num integer, OUT square integer, OUT cube integer) returns record
    language plpgsql
as
$$
begin
    square = pow(num, 2);
    cube = pow(num, 3);
end;
$$;

alter function for_h(integer, out integer, out integer) owner to postgres;

