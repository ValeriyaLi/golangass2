create function schema_update() returns trigger
    language plpgsql
as
$$
declare
    operation_date timestamp;
begin
    insert into my_table_history (operation_name, operation_datetime)
    values (tg_op, now());
    return new;
end;
$$;

alter function schema_update() owner to postgres;

