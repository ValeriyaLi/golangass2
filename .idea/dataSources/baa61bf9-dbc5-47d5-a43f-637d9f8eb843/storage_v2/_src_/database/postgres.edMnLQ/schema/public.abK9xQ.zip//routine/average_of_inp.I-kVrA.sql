create function average_of_inp(VARIADIC l numeric[], OUT res numeric) returns numeric
    language plpgsql
as
$$
begin
    select into res avg(l[i]) from generate_subscripts(l, 1) g(i);
end;
$$;

alter function average_of_inp(numeric[], out numeric) owner to postgres;

