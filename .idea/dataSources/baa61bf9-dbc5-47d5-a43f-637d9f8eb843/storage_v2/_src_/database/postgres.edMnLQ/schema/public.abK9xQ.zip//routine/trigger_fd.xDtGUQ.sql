create function trigger_fd() returns trigger
    language plpgsql
as
$$
    BEGIN
--         delete from tab1 where id = 1;
        raise notice 'Cannot delete this row';
    end;
    $$;

alter function trigger_fd() owner to postgres;

