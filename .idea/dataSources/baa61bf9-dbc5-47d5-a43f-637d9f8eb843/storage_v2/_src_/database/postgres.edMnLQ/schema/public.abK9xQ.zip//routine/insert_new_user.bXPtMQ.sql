create procedure insert_new_user(IN namee character varying, IN phonee character varying)
    language plpgsql
as
$$
begin

    insert into Book(person_name, phone_number) values ($1, $2);
end;
$$;

alter procedure insert_new_user(varchar, varchar) owner to postgres;

