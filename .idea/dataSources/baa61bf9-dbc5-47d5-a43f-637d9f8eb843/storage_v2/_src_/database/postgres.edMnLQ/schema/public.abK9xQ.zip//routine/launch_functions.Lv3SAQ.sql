create function launch_functions() returns trigger
    language plpgsql
as
$$
begin
    raise notice '%', public.check_even(new.item_price::numeric);
    raise notice '%', public.average_of_inp(new.item_price::numeric);
    return new;
end;
$$;

alter function launch_functions() owner to postgres;

