create function increment_by_1(num numeric) returns numeric
    language plpgsql
as
$$
begin
    return num + 1;
end;
$$;

alter function increment_by_1(numeric) owner to postgres;

