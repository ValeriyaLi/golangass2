create procedure increase_and_provide_features(IN c_id integer)
    language plpgsql
as
$$
declare
    cnt        int;
    cnt1       int;
    experience int;
begin
    select workexperience into experience from my_table where id = c_id;
    cnt = experience / 2;
    cnt1 = experience / 5;
    if cnt > 0 then
        update my_table set discount = 10 where id = c_id;
    end if;
    for i in 0..cnt
        loop
            update my_table set salary = salary * 1.1 where c_id = id;
        end loop;
    for i in 0..cnt1
        loop
            update my_table set discount = discount * 1.01 where c_id = id;
        end loop;
    commit;
end;
$$;

alter procedure increase_and_provide_features(integer) owner to postgres;

