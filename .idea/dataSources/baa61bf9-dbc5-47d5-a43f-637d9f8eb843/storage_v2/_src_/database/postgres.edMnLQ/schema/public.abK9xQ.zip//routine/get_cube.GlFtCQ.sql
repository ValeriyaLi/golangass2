create function get_cube(num numeric) returns numeric
    language plpgsql
as
$$
begin
    return pow(num, 3);
end;
$$;

alter function get_cube(numeric) owner to postgres;

