create function compute_age() returns trigger
    language plpgsql
as
$$
begin
    NEW.age := date_part('year', now()) - date_part('year', NEW.date_of_birth::date);
    return new;
end;
$$;

alter function compute_age() owner to postgres;

