create procedure employee_privy_40(IN c_id integer)
    language plpgsql
as
$$
declare
    c_age      integer;
    experience integer;
begin
    select age into c_age from my_table where id = c_id;
    select workexperience into experience from my_table where id = c_id;
    if c_age >= 40 then
        update my_table set salary = salary * 1.15 where id = c_id;
    end if;
    if experience > 8 then
        update my_table set salary = salary * 1.15, discount = 20 where id = c_id;
    end if;
    commit;
end;
$$;

alter procedure employee_privy_40(integer) owner to postgres;

