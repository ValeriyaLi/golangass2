create function add_tax() returns trigger
    language plpgsql
as
$$
BEGIN
    new.item_price = new.item_price * 1.12;
    return new;
end;
$$;

alter function add_tax() owner to postgres;

