create function trigger_fc() returns trigger
    language plpgsql
as
$$
    BEGIN
        if(tab1.id  is null or tab1.date_of_birth is null or tab1.name is null or tab1.salary is null or tab1.age is null)
            then insert into tab1 values (12, 'Timur', '2000-12-12', 20, 10000, 5, 10);
        end if;
        update tab1 set descount = descount + 0.12;
    end;
    $$;

alter function trigger_fc() owner to postgres;

