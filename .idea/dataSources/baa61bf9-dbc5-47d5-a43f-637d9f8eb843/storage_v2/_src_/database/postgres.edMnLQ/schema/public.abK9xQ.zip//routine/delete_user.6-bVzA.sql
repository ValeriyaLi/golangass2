create procedure delete_user(IN del_value text)
    language plpgsql
as
$$
begin
    delete
    from book
    where person_name = $1;
end;
$$;

alter procedure delete_user(text) owner to postgres;

