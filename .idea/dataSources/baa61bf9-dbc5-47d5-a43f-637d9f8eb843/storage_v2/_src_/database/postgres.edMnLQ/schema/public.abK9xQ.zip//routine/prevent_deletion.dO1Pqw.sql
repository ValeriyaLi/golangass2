create function prevent_deletion() returns trigger
    language plpgsql
as
$$
begin
    raise exception 'Delete operation is blocked.';
end;
$$;

alter function prevent_deletion() owner to postgres;

