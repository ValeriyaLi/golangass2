create function getrecord(namee character varying) returns record
    language plpgsql
as
$$
    declare
        person_name record;
begin
    select * into person_name from Book where book.person_name = $1;
    return person_name;
end;
$$;

alter function getrecord(varchar) owner to postgres;

