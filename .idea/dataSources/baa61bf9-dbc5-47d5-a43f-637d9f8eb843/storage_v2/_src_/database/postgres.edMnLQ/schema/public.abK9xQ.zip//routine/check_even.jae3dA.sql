create function check_even(num1 numeric) returns boolean
    language plpgsql
as
$$
begin
    return num1 % 2 = 0;
end;
$$;

alter function check_even(numeric) owner to postgres;

