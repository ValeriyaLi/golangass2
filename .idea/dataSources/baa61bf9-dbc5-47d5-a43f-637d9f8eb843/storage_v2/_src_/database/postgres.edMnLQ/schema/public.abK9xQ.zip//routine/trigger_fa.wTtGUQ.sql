create function trigger_fa() returns trigger
    language plpgsql
as
$$BEGIN
        return current_timestamp;
    end;$$;

alter function trigger_fa() owner to postgres;

