create function get_sum(num1 numeric, num2 numeric) returns numeric
    language plpgsql
as
$$
begin
    return num1 + num2;
end;
$$;

alter function get_sum(numeric, numeric) owner to postgres;

